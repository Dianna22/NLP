package accuracy;

public class POS_tag {
	
	public String name;
	public int frequency=0;

}
