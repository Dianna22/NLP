package accuracy;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileWriter;

public class filereader {
	public static void main(String[] args) {
		try{
			

			//file one
			FileReader fr = new FileReader("Input/POS_tagger_output.txt");
			BufferedReader br = new BufferedReader(fr);
			String line;
			int numberOfLines =0;
			ArrayList<String[]> x = new ArrayList<String[]>();
			// reading each line
			while((line = br.readLine()) != null)
			{
				//spliting lines by space
				String[] temp_string = line.split("\\s");
				//System.out.println(line);
				x.add(temp_string);
				//System.out.println("********");
				numberOfLines++;
			}
			System.out.println("Number of lines: " + numberOfLines);
			
			
			br.close();
			fr.close();
			
			/*//printing array of file one
			for(int i=0; i<x.size();i++)
			{
				for(int j=0; j<x.get(i).length;j++)
				{
					System.out.println(x.get(i)[j]);
				}
				System.out.println("-----------------------------");
			}*/
			
			//file two
			FileReader fr2 = new FileReader("Input/POS_results_changed.txt");
			BufferedReader br2 = new BufferedReader(fr2);
			String line2;
			int numberOfLines2 =0;
			ArrayList<String[]> x2 = new ArrayList<String[]>();
			// reading each line
			while((line2 = br2.readLine()) != null)
			{
				//spliting lines by space
				String[] temp_string2 = line2.split("\\s");
				//System.out.println(line);
				x2.add(temp_string2);
				//System.out.println("********");
				numberOfLines2++;
			}
			System.out.println("Number of lines: " + numberOfLines2);
			
			
			br2.close();
			fr2.close();
			
			//printing array of file two
			/*for(int i=0; i<x2.size();i++)
			{
				for(int j=0; j<x2.get(i).length;j++)
				{
					System.out.println(x2.get(i)[j]);
				}
				System.out.println("-----------------------------");
			}*/
			
			//calculate accuracy
			int accuracy=0;
			for (int i=0; i<x.size();i++)
			{
				for (int j=0; j<x.get(i).length; j++)
				{
					if(x.get(i)[j].equals(x2.get(i)[j]) && x.get(i).length == x2.get(i).length)
					{
						accuracy++;
					}
					else
					{
						boolean is_there=false;
						for(int k=0; k<x2.get(i).length; k++){
							
							if(x.get(i)[j].equals(x2.get(i)[k]))
									{
								is_there= true;
									}
						}
						if(is_there == true)
						{
							accuracy++;
						}
						System.out.println(x.get(i)[j] + " #### " + x2.get(i)[j] );
					}
				}
			}
			System.out.println("accuracy: " + accuracy);
			double accuracyP = accuracy/96457.0;
			System.out.println("accuracy: " + accuracyP *100 + "%");
			
			
			
		}catch (IOException e)
		{
			e.printStackTrace();
		}

}
}

